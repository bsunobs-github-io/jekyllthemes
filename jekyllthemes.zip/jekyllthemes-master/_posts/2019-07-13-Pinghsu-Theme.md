---
layout: post
title: Pinghsu theme
date: 2019-07-13 13:30:00
homepage: https://github.com/lightfish-zhang/pinghsu-jekyll
download: https://github.com/lightfish-zhang/pinghsu-jekyll/archive/master.zip
demo: https://lightfish.cn/
author: Lightfish Zhang
thumbnail: pinghsu-jekyll.png
license: MIT
license_link: https://github.com/lightfish-zhang/pinghsu-jekyll/blob/master/LICENSE
---


a jekyll theme which is based on a typecho theme pinghsu, it count make you homepage illustrated !
