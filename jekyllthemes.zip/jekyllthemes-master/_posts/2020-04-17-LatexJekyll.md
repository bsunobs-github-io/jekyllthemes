---
layout: post
title: Latex Jekyll
date: 2020-04-17 20:00:00
homepage: https://github.com/Hammie217/LatexJekyll
download: https://github.com/Hammie217/LatexJekyll
demo: https://unruffled-ardinghelli-55d901.netlify.app/
author: Hamish Sams
thumbnail: LatexJekyll.png
license: WTFPL
---

A super simple LaTeX style website. Feel free to build upon this however you like.

Features

- Super easy
- Super fast
- Open source
- Do what you want with it!