---
layout: post
title: Leaf
date: 2020-02-26 
homepage: https://github.com/SupunKavinda/jekyll-theme-leaf
download: https://github.com/SupunKavinda/jekyll-theme-leaf/archive/0.1.0.zip
demo: https://supunkavinda.github.io/jekyll-theme-leaf/
author: Supun Kavinda
thumbnail: leaf.png
license: MIT License
license_link: https://github.com/SupunKavinda/jekyll-theme-leaf/blob/0.1.0/LICENSE.txt
---

Minimal yet beautiful Jekyll theme for dark background lovers.
